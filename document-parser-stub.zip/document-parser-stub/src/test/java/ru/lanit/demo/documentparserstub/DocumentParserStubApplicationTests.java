package ru.lanit.demo.documentparserstub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentParserStubApplicationTests {

	@Test
	void contextLoads() {
	}

}
