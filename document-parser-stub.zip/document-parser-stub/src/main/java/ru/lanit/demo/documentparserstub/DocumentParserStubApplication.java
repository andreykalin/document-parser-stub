package ru.lanit.demo.documentparserstub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentParserStubApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocumentParserStubApplication.class, args);
	}

}
